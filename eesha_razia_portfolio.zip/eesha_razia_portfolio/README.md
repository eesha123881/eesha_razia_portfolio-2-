# Eesha Razia — Portfolio Website

A responsive, single-page portfolio website built with HTML, CSS and JavaScript.

## Preview locally
1. Extract the ZIP file.
2. Open `index.html` in a browser.

## Files
- `index.html` — website content
- `style.css` — layout, colours and responsive design
- `script.js` — mobile navigation and current year

## Before publishing
Please verify the skills list and add:
- Eesha's exact internship role, tasks and tools used at Technik Nest.
- The features, technologies and screenshots of the “Trip Planning for AJK” app.
- Any public GitHub, LinkedIn or other professional profile links.

The current version intentionally avoids inventing internship duties or project features.
